/* Make Each author have his own array */

console.log("The scripts have started!");

$(function () {
    // All jQuery code goes here
    $('.dropdownMenu > li').hover(function () {
        $(this).children("ul").slideToggle(200);
    })
})

jQuery(document).ready(function ($) {

})
function search(nameVal, myArray) {
    var newArray = [];
    for (var i=0; i< myArray.length; i++) {
        console.log(myArray[i]);
        if (myArray[i].author.split(" ").pop() === nameVal) {
            newArray.push(myArray[i]);
        }
        else if (myArray[i].topic.split(" ").pop() === nameVal) {
            newArray.push(myArray[i]);
        }
    }
    return newArray;
}



$(function() {
    console.log("Reading the JSON file.");
    $.getJSON("../../js/quotes.json", function(data){
            console.log(data);
            var classT = $("body").attr("class");
            console.log(classT);
            var classA = classT.split(" ");
        console.log(classA[1]);
            var quoteArray = search(classA[1], data);
            console.log(quoteArray);
                data.filter("");

            })



    });








function Quotes() {


    var quoteArray = Object.keys(id);
    var randomNumber = Math.random();
    var fullQuoteIndex = Math.floor(randomNumber * quoteArray.length);

    var randomKey = quoteArray[fullQuoteIndex];


};









//var animalArray  = Object.keys(animals);
//var randomNumber = Math.random();
//var animalIndex  = Math.floor(randomNumber * animalArray.length);
//
//var randomKey    = animalArray[animalIndex];
// This will course this will return the value of the randomKey
// instead of a fresh random value
//var randomValue  = animals[randomKey];


/* Random Key
console.log(Object.keys(animals)[Math.floor(Math.random()*Object.keys(animals).length)]);

// Random Value
console.log(animals[Object.keys(animals)[Math.floor(Math.random()*Object.keys(animals).length)]]);
*/
